package com.gabedeveloper.minimapa;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = Minimapa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class InputHandler {

    @SubscribeEvent
    public static void aoTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        while (ClientSetup.TOGGLE_KEY.consumeClick()) {
            HudMinimapRenderer.underground = !HudMinimapRenderer.underground;
            HudMinimapRenderer.forceUpdate = true;
        }

        HudMinimapRenderer.onClientTick(mc);
    }

    @SubscribeEvent
    public static void aoClicarMouse(InputEvent.MouseButton.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null) return;
        if (mc.player == null) return;
        if (event.getButton() != GLFW.GLFW_MOUSE_BUTTON_LEFT || event.getAction() != GLFW.GLFW_PRESS) return;

        long window = mc.getWindow().getWindow();
        double[] xpos = new double[1];
        double[] ypos = new double[1];
        GLFW.glfwGetCursorPos(window, xpos, ypos);

        double escalaX = (double) mc.getWindow().getGuiScaledWidth() / mc.getWindow().getScreenWidth();
        double escalaY = (double) mc.getWindow().getGuiScaledHeight() / mc.getWindow().getScreenHeight();
        double mouseX = xpos[0] * escalaX;
        double mouseY = ypos[0] * escalaY;

        int bx = HudMinimapRenderer.buttonX;
        int by = HudMinimapRenderer.buttonY;
        int bw = HudMinimapRenderer.buttonW;
        int bh = HudMinimapRenderer.buttonH;

        if (mouseX >= bx && mouseX <= bx + bw && mouseY >= by && mouseY <= by + bh) {
            HudMinimapRenderer.underground = !HudMinimapRenderer.underground;
            HudMinimapRenderer.forceUpdate = true;
            event.setCanceled(true);
        }
    }
}
