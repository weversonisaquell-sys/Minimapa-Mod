package com.gabedeveloper.minimapa.mixin;

import com.gabedeveloper.minimapa.HudMinimapRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void minimapa$aoClicar(long window, int button, int action, int mods, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.currentScreen != null) return;
        if (client.player == null) return;
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT || action != GLFW.GLFW_PRESS) return;

        double escalaX = (double) client.getWindow().getScaledWidth() / client.getWindow().getWidth();
        double escalaY = (double) client.getWindow().getScaledHeight() / client.getWindow().getHeight();
        double mouseX = client.mouse.getX() * escalaX;
        double mouseY = client.mouse.getY() * escalaY;

        int bx = HudMinimapRenderer.buttonX;
        int by = HudMinimapRenderer.buttonY;
        int bw = HudMinimapRenderer.buttonW;
        int bh = HudMinimapRenderer.buttonH;

        if (mouseX >= bx && mouseX <= bx + bw && mouseY >= by && mouseY <= by + bh) {
            HudMinimapRenderer.underground = !HudMinimapRenderer.underground;
            HudMinimapRenderer.forceUpdate = true;
            ci.cancel();
        }
    }
}
