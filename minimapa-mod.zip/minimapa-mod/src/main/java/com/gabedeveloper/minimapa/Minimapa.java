package com.gabedeveloper.minimapa;

import net.minecraftforge.fml.common.Mod;

@Mod(Minimapa.MODID)
public class Minimapa {
    public static final String MODID = "minimapa";

    public Minimapa() {
        // Mod client-only: toda a lógica fica em ClientSetup e InputHandler.
    }
}
