package com.gabedeveloper.minimapa;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = Minimapa.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    public static final KeyMapping TOGGLE_KEY = new KeyMapping(
            "key.minimapa.toggle",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_M,
            "key.categories.minimapa"
    );

    @SubscribeEvent
    public static void registrarOverlay(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("minimapa_overlay", HudMinimapRenderer::render);
    }

    @SubscribeEvent
    public static void registrarTecla(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_KEY);
    }
}
