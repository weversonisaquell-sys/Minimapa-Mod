package com.gabedeveloper.minimapa;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class MinimapaClient implements ClientModInitializer {

    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        // Registra o desenho do minimapa por cima do HUD do jogo
        HudRenderCallback.EVENT.register(HudMinimapRenderer::render);

        // Registra a atualização periódica do terreno (evita recalcular todo frame)
        ClientTickEvents.END_CLIENT_TICK.register(HudMinimapRenderer::onClientTick);

        // Tecla de atalho "M" para alternar Superfície/Subterrâneo.
        // Muito útil no PojavLauncher: dá pra criar um botão de toque personalizado
        // nas configurações de controle e vincular a essa tecla.
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.minimapa.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                "key.categories.minimapa"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                HudMinimapRenderer.underground = !HudMinimapRenderer.underground;
                HudMinimapRenderer.forceUpdate = true;
            }
        });
    }
}
