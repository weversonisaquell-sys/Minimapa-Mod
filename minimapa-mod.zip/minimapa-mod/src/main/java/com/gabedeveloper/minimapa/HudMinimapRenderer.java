package com.gabedeveloper.minimapa;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public class HudMinimapRenderer {

    // ==== Configurações gerais ====
    private static final int RADIUS_CHUNKS = 2;
    private static final int RADIUS_BLOCKS = RADIUS_CHUNKS * 16; // 32 blocos
    private static final int DIAMETRO_BLOCOS = RADIUS_BLOCKS * 2; // 64 blocos
    private static final int ESCALA_PIXEL = 2; // cada bloco vira 2x2 px na tela
    private static final int TAMANHO_MAPA = DIAMETRO_BLOCOS * ESCALA_PIXEL; // 128 px

    private static final int COR_JOGADOR = 0xFF90EE90;   // verde claro
    private static final int COR_HOSTIL = 0xFFFF3B3B;    // vermelho
    private static final int COR_PACIFICO = 0xFFFFD700;  // amarelo
    private static final int COR_EU = 0xFF00E5FF;        // ciano (você, no centro)

    // ==== Estado compartilhado com o InputHandler ====
    public static boolean underground = false;
    public static boolean forceUpdate = true;
    public static int buttonX, buttonY, buttonW = 22, buttonH = 22;

    // ==== Cache do terreno ====
    private static final int[] terrainColors = new int[DIAMETRO_BLOCOS * DIAMETRO_BLOCOS];
    private static int tickCounter = 0;
    private static final int TICKS_ENTRE_ATUALIZACOES = 10; // atualiza a cada 0.5s

    public static void onClientTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        tickCounter++;
        if (forceUpdate || tickCounter >= TICKS_ENTRE_ATUALIZACOES) {
            tickCounter = 0;
            forceUpdate = false;
            atualizarTerreno(mc);
        }
    }

    private static void atualizarTerreno(Minecraft mc) {
        ClientLevel level = mc.level;
        BlockPos jogadorPos = mc.player.blockPosition();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        int indice = 0;
        for (int dz = -RADIUS_BLOCKS; dz < RADIUS_BLOCKS; dz++) {
            for (int dx = -RADIUS_BLOCKS; dx < RADIUS_BLOCKS; dx++) {
                pos.set(jogadorPos.getX() + dx, jogadorPos.getY(), jogadorPos.getZ() + dz);
                int cor = underground
                        ? amostrarSubterraneo(level, pos, jogadorPos.getY())
                        : amostrarSuperficie(level, pos);
                terrainColors[indice++] = cor;
            }
        }
    }

    private static int amostrarSuperficie(ClientLevel level, BlockPos.MutableBlockPos pos) {
        int topoY = level.getHeight(Heightmap.Types.WORLD_SURFACE, pos.getX(), pos.getZ()) - 1;
        pos.setY(topoY);
        BlockState estado = level.getBlockState(pos);
        if (estado.isAir()) return 0xFF1B1B1B;
        MapColor cor = estado.getMapColor(level, pos);
        return 0xFF000000 | cor.col;
    }

    private static int amostrarSubterraneo(ClientLevel level, BlockPos.MutableBlockPos pos, int playerY) {
        int limiteInferior = Math.max(level.getMinBuildHeight(), playerY - 8);
        for (int y = playerY; y >= limiteInferior; y--) {
            pos.setY(y);
            BlockState estado = level.getBlockState(pos);
            if (!estado.isAir()) {
                MapColor cor = estado.getMapColor(level, pos);
                return 0xFF000000 | cor.col;
            }
        }
        return 0xFF0A0A0A; // caverna/vazio: quase preto
    }

    // ==== Renderização por frame ====
    public static void render(ForgeGui gui, GuiGraphics ctx, float partialTick, int screenWidth, int screenHeight) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;

        int mapX = screenWidth - TAMANHO_MAPA - 12;
        int mapY = 12;

        desenharFundo(ctx, mapX, mapY);
        desenharTerreno(ctx, mapX, mapY);
        desenharEntidades(ctx, mc, mapX, mapY);
        desenharBorda(ctx, mapX, mapY);
        desenharBotao(ctx, mc, mapX, mapY);
        desenharTitulo(ctx, mc, mapX, mapY);
    }

    private static void desenharFundo(GuiGraphics ctx, int mapX, int mapY) {
        ctx.fill(mapX - 2, mapY - 2, mapX + TAMANHO_MAPA + 2, mapY + TAMANHO_MAPA + 2, 0x80000000);
    }

    private static void desenharTerreno(GuiGraphics ctx, int mapX, int mapY) {
        int centro = TAMANHO_MAPA / 2;
        int indice = 0;
        for (int bz = 0; bz < DIAMETRO_BLOCOS; bz++) {
            for (int bx = 0; bx < DIAMETRO_BLOCOS; bx++) {
                int cor = terrainColors[indice++];
                int px = mapX + bx * ESCALA_PIXEL;
                int py = mapY + bz * ESCALA_PIXEL;

                int distX = (px - mapX + ESCALA_PIXEL / 2) - centro;
                int distY = (py - mapY + ESCALA_PIXEL / 2) - centro;
                if (distX * distX + distY * distY > centro * centro) continue; // recorte circular

                ctx.fill(px, py, px + ESCALA_PIXEL, py + ESCALA_PIXEL, cor);
            }
        }
    }

    private static void desenharEntidades(GuiGraphics ctx, Minecraft mc, int mapX, int mapY) {
        int centro = TAMANHO_MAPA / 2;
        double px0 = mc.player.getX();
        double pz0 = mc.player.getZ();

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player) continue;
            double dx = entity.getX() - px0;
            double dz = entity.getZ() - pz0;
            double distancia = Math.sqrt(dx * dx + dz * dz);
            if (distancia > RADIUS_BLOCKS) continue;

            int cor;
            if (entity instanceof Player) {
                cor = COR_JOGADOR;
            } else if (entity instanceof Monster) {
                cor = COR_HOSTIL;
            } else if (entity instanceof Mob) {
                cor = COR_PACIFICO;
            } else {
                continue; // ignora itens, flechas, etc.
            }

            int px = mapX + centro + (int) Math.round(dx * ESCALA_PIXEL);
            int py = mapY + centro + (int) Math.round(dz * ESCALA_PIXEL);
            ctx.fill(px - 2, py - 2, px + 2, py + 2, cor);
        }

        // Ponto do próprio jogador, sempre no centro
        int cx = mapX + centro;
        int cy = mapY + centro;
        ctx.fill(cx - 2, cy - 2, cx + 2, cy + 2, COR_EU);
    }

    private static void desenharBorda(GuiGraphics ctx, int mapX, int mapY) {
        int x1 = mapX - 2, y1 = mapY - 2;
        int x2 = mapX + TAMANHO_MAPA + 2, y2 = mapY + TAMANHO_MAPA + 2;
        int cor = 0xFFFFFFFF;
        ctx.fill(x1, y1, x2, y1 + 1, cor);
        ctx.fill(x1, y2 - 1, x2, y2, cor);
        ctx.fill(x1, y1, x1 + 1, y2, cor);
        ctx.fill(x2 - 1, y1, x2, y2, cor);
    }

    private static void desenharBotao(GuiGraphics ctx, Minecraft mc, int mapX, int mapY) {
        buttonW = 22;
        buttonH = 22;
        buttonX = mapX - buttonW - 6;
        buttonY = mapY;

        ctx.fill(buttonX, buttonY, buttonX + buttonW, buttonY + buttonH, 0xCC202020);

        int x1 = buttonX, y1 = buttonY, x2 = buttonX + buttonW, y2 = buttonY + buttonH;
        int cor = 0xFFFFFFFF;
        ctx.fill(x1, y1, x2, y1 + 1, cor);
        ctx.fill(x1, y2 - 1, x2, y2, cor);
        ctx.fill(x1, y1, x1 + 1, y2, cor);
        ctx.fill(x2 - 1, y1, x2, y2, cor);

        String rotulo = underground ? "SUB" : "SUP";
        int largura = mc.font.width(rotulo);
        ctx.drawString(mc.font, rotulo,
                buttonX + (buttonW - largura) / 2,
                buttonY + (buttonH - 8) / 2,
                0xFFFFFFFF, true);
    }

    private static void desenharTitulo(GuiGraphics ctx, Minecraft mc, int mapX, int mapY) {
        String titulo = underground ? "Subterrâneo" : "Superfície";
        int largura = mc.font.width(titulo);
        ctx.drawString(mc.font, titulo,
                mapX + (TAMANHO_MAPA - largura) / 2,
                mapY + TAMANHO_MAPA + 6,
                0xFFFFFFFF, true);
    }
}
