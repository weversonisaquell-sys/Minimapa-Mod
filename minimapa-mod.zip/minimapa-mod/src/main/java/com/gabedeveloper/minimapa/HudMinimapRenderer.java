package com.gabedeveloper.minimapa;

import net.minecraft.block.MapColor;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

public class HudMinimapRenderer {

    // ==== Configurações gerais ====
    private static final int RADIUS_CHUNKS = 2;
    private static final int RADIUS_BLOCKS = RADIUS_CHUNKS * 16; // 32 blocos
    private static final int DIAMETRO_BLOCOS = RADIUS_BLOCKS * 2; // 64 blocos
    private static final int ESCALA_PIXEL = 2; // cada bloco vira 2x2 px na tela
    private static final int TAMANHO_MAPA = DIAMETRO_BLOCOS * ESCALA_PIXEL; // 128 px

    private static final int COR_JOGADOR = 0xFF90EE90;   // verde claro
    private static final int COR_HOSTIL = 0xFFFF3B3B;    // vermelho
    private static final int COR_PACIFICO = 0xFFFFD700;  // amarelo
    private static final int COR_EU = 0xFF00E5FF;        // ciano (você, no centro)

    // ==== Estado compartilhado com o Mixin do mouse ====
    public static boolean underground = false;
    public static boolean forceUpdate = true;
    public static int buttonX, buttonY, buttonW = 22, buttonH = 22;

    // ==== Cache do terreno ====
    private static final int[] terrainColors = new int[DIAMETRO_BLOCOS * DIAMETRO_BLOCOS];
    private static int tickCounter = 0;
    private static final int TICKS_ENTRE_ATUALIZACOES = 10; // atualiza a cada 0.5s

    public static void onClientTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        tickCounter++;
        if (forceUpdate || tickCounter >= TICKS_ENTRE_ATUALIZACOES) {
            tickCounter = 0;
            forceUpdate = false;
            atualizarTerreno(client);
        }
    }

    private static void atualizarTerreno(MinecraftClient client) {
        ClientWorld world = client.world;
        BlockPos jogadorPos = client.player.getBlockPos();
        BlockPos.Mutable pos = new BlockPos.Mutable();

        int indice = 0;
        for (int dz = -RADIUS_BLOCKS; dz < RADIUS_BLOCKS; dz++) {
            for (int dx = -RADIUS_BLOCKS; dx < RADIUS_BLOCKS; dx++) {
                pos.set(jogadorPos.getX() + dx, jogadorPos.getY(), jogadorPos.getZ() + dz);
                int cor = underground
                        ? amostrarSubterraneo(world, pos, jogadorPos.getY())
                        : amostrarSuperficie(world, pos);
                terrainColors[indice++] = cor;
            }
        }
    }

    private static int amostrarSuperficie(ClientWorld world, BlockPos.Mutable pos) {
        int topoY = world.getTopY(Heightmap.Type.WORLD_SURFACE, pos.getX(), pos.getZ()) - 1;
        pos.setY(topoY);
        BlockState estado = world.getBlockState(pos);
        if (estado.isAir()) return 0xFF1B1B1B;
        MapColor cor = estado.getMapColor(world, pos);
        return 0xFF000000 | cor.color;
    }

    private static int amostrarSubterraneo(ClientWorld world, BlockPos.Mutable pos, int playerY) {
        int limiteInferior = Math.max(world.getBottomY(), playerY - 8);
        for (int y = playerY; y >= limiteInferior; y--) {
            pos.setY(y);
            BlockState estado = world.getBlockState(pos);
            if (!estado.isAir()) {
                MapColor cor = estado.getMapColor(world, pos);
                return 0xFF000000 | cor.color;
            }
        }
        return 0xFF0A0A0A; // caverna/vazio: quase preto
    }

    // ==== Renderização por frame ====
    public static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.options.hudHidden) return;

        int scaledWidth = client.getWindow().getScaledWidth();
        int mapX = scaledWidth - TAMANHO_MAPA - 12;
        int mapY = 12;

        desenharFundo(ctx, mapX, mapY);
        desenharTerreno(ctx, mapX, mapY);
        desenharEntidades(ctx, client, mapX, mapY);
        desenharBorda(ctx, mapX, mapY);
        desenharBotao(ctx, client, mapX, mapY);
        desenharTitulo(ctx, client, mapX, mapY);
    }

    private static void desenharFundo(DrawContext ctx, int mapX, int mapY) {
        ctx.fill(mapX - 2, mapY - 2, mapX + TAMANHO_MAPA + 2, mapY + TAMANHO_MAPA + 2, 0x80000000);
    }

    private static void desenharTerreno(DrawContext ctx, int mapX, int mapY) {
        int centro = TAMANHO_MAPA / 2;
        int indice = 0;
        for (int bz = 0; bz < DIAMETRO_BLOCOS; bz++) {
            for (int bx = 0; bx < DIAMETRO_BLOCOS; bx++) {
                int cor = terrainColors[indice++];
                int px = mapX + bx * ESCALA_PIXEL;
                int py = mapY + bz * ESCALA_PIXEL;

                int distX = (px - mapX + ESCALA_PIXEL / 2) - centro;
                int distY = (py - mapY + ESCALA_PIXEL / 2) - centro;
                if (distX * distX + distY * distY > centro * centro) continue; // recorte circular

                ctx.fill(px, py, px + ESCALA_PIXEL, py + ESCALA_PIXEL, cor);
            }
        }
    }

    private static void desenharEntidades(DrawContext ctx, MinecraftClient client, int mapX, int mapY) {
        int centro = TAMANHO_MAPA / 2;
        double px0 = client.player.getX();
        double pz0 = client.player.getZ();

        for (Entity entity : client.world.getEntities()) {
            if (entity == client.player) continue;
            double dx = entity.getX() - px0;
            double dz = entity.getZ() - pz0;
            double distancia = Math.sqrt(dx * dx + dz * dz);
            if (distancia > RADIUS_BLOCKS) continue;

            int cor;
            if (entity instanceof PlayerEntity) {
                cor = COR_JOGADOR;
            } else if (entity instanceof HostileEntity) {
                cor = COR_HOSTIL;
            } else if (entity instanceof MobEntity) {
                cor = COR_PACIFICO;
            } else {
                continue; // ignora itens, flechas, etc.
            }

            int px = mapX + centro + (int) Math.round(dx * ESCALA_PIXEL);
            int py = mapY + centro + (int) Math.round(dz * ESCALA_PIXEL);
            ctx.fill(px - 2, py - 2, px + 2, py + 2, cor);
        }

        // Ponto do próprio jogador, sempre no centro
        int cx = mapX + centro;
        int cy = mapY + centro;
        ctx.fill(cx - 2, cy - 2, cx + 2, cy + 2, COR_EU);
    }

    private static void desenharBorda(DrawContext ctx, int mapX, int mapY) {
        ctx.drawBorder(mapX - 2, mapY - 2, TAMANHO_MAPA + 4, TAMANHO_MAPA + 4, 0xFFFFFFFF);
    }

    private static void desenharBotao(DrawContext ctx, MinecraftClient client, int mapX, int mapY) {
        buttonW = 22;
        buttonH = 22;
        buttonX = mapX - buttonW - 6;
        buttonY = mapY;

        ctx.fill(buttonX, buttonY, buttonX + buttonW, buttonY + buttonH, 0xCC202020);
        ctx.drawBorder(buttonX, buttonY, buttonW, buttonH, 0xFFFFFFFF);

        String rotulo = underground ? "SUB" : "SUP";
        int largura = client.textRenderer.getWidth(rotulo);
        ctx.drawText(client.textRenderer, rotulo,
                buttonX + (buttonW - largura) / 2,
                buttonY + (buttonH - 8) / 2,
                0xFFFFFFFF, true);
    }

    private static void desenharTitulo(DrawContext ctx, MinecraftClient client, int mapX, int mapY) {
        String titulo = underground ? "Subterrâneo" : "Superfície";
        int largura = client.textRenderer.getWidth(titulo);
        ctx.drawText(client.textRenderer, titulo,
                mapX + (TAMANHO_MAPA - largura) / 2,
                mapY + TAMANHO_MAPA + 6,
                0xFFFFFFFF, true);
    }
}
