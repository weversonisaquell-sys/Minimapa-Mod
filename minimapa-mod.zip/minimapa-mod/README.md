# Minimapa GABEDEVELOPER (Forge — Minecraft 1.20.1)

Mod de minimapa no canto superior direito da tela, agora em **MinecraftForge**
(compatível com o seu perfil Forge no PojavLauncher):

- Raio de **2 chunks** (32 blocos) ao redor do jogador.
- Pontos **verde claro** = jogadores.
- Pontos **vermelhos** = mobs hostis.
- Pontos **amarelos** = mobs pacíficos.
- Ponto **ciano** no centro = você.
- Botão **"SUP/SUB"** ao lado do mapa para alternar entre superfície e subterrâneo.
- Tecla **M** também alterna o modo (recomendado no PojavLauncher, veja abaixo).

## 1. Como gerar o .jar usando o GitHub

O repositório já deve ter o `.github/workflows/build.yml` configurado (não
precisa mexer nele de novo, só o Gradle usado mudou para `8.1.1`, compatível
com o ForgeGradle).

1. Apague o `minimapa-mod.zip` antigo do repositório (o Fabric).
2. Faça upload deste novo `minimapa-mod.zip` (Forge) no lugar dele, na raiz
   do repositório.
3. Vá na aba **Actions**, espere o workflow "Compilar Minimapa" rodar.
   ForgeGradle baixa e prepara o Minecraft na primeira vez, então pode
   demorar uns 5 a 10 minutos — é normal.
4. Baixe o artefato **Minimapa-Mod-jar** quando terminar (ícone verde ✅).

> Se o build falhar, me manda o log (igual fizemos antes) que eu ajusto a
> versão do Forge/mapeamento em `gradle.properties`.

## 2. Como instalar no PojavLauncher

1. No PojavLauncher, instale um perfil com **Forge 1.20.1** (não Fabric).
2. Coloque o `.jar` gerado dentro de `.minecraft/mods/` desse perfil Forge.
3. Inicie o jogo usando esse perfil. O minimapa aparece no canto superior
   direito automaticamente, junto dos seus outros mods Forge.

## 3. Alternando Superfície/Subterrâneo no toque (Pojav)

Como toque em tela pode não gerar clique de mouse de forma confiável:

1. Vá em **Configurações → Controles → Botões personalizados** do Pojav.
2. Adicione um botão novo vinculado à tecla **M**.
3. Toque nesse botão em jogo para alternar entre Superfície e Subterrâneo.

O botão desenhado ao lado do minimapa também funciona com mouse/touchpad
(quando o Pojav está em modo "mouse virtual").

## Estrutura do projeto

```
minimapa-mod/
├── build.gradle
├── settings.gradle
├── gradle.properties
└── src/main/
    ├── java/com/gabedeveloper/minimapa/
    │   ├── Minimapa.java             -> classe principal (@Mod)
    │   ├── ClientSetup.java          -> registra overlay e tecla de atalho
    │   ├── InputHandler.java         -> tick, tecla M e clique no botão
    │   └── HudMinimapRenderer.java   -> desenho do mapa/entidades/botão
    └── resources/
        ├── META-INF/mods.toml
        └── pack.mcmeta
```
