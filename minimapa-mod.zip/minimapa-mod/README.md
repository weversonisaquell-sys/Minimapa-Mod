# Minimapa GABEDEVELOPER (Fabric — Minecraft 1.20.1)

Mod de minimapa no canto superior direito da tela:

- Raio de **2 chunks** (32 blocos) ao redor do jogador.
- Pontos **verde claro** = jogadores.
- Pontos **vermelhos** = mobs hostis.
- Pontos **amarelos** = mobs pacíficos.
- Ponto **ciano** no centro = você.
- Botão **"SUP/SUB"** ao lado do mapa para alternar entre renderizar a
  superfície (heightmap) e o subterrâneo (bloco mais próximo abaixo de você,
  simulando visão de caverna).
- Tecla **M** também alterna o modo (útil no PojavLauncher, veja abaixo).

## 1. Como gerar o .jar usando o GitHub (sem precisar compilar no seu PC)

1. Crie um repositório novo no GitHub (público ou privado).
2. Suba TODOS os arquivos deste .zip para a raiz do repositório
   (mantendo a estrutura de pastas exatamente como está).
3. Vá na aba **Actions** do repositório. O workflow "Compilar Minimapa"
   deve rodar automaticamente após o push (se não rodar, clique nele e
   depois em **Run workflow**).
4. Espere terminar (ícone verde ✅). Clique na execução mais recente e
   baixe o artefato **Minimapa-Mod-jar** — dentro dele está o `.jar` pronto.

> Se o build falhar por causa de alguma versão do Fabric API/Loom não
> existir mais, abra `gradle.properties` e ajuste `fabric_version` /
> `yarn_mappings` para as versões atuais listadas em
> https://fabricmc.net/develop/ (mantendo `minecraft_version=1.20.1`).

## 2. Como instalar no PojavLauncher

1. Dentro do PojavLauncher, instale o **Fabric Loader para a versão 1.20.1**
   (menu de instalação de versões → Fabric).
2. Coloque o arquivo `.jar` gerado dentro da pasta:
   `.minecraft/mods/` do seu perfil Fabric no Pojav.
3. Inicie o jogo usando o perfil Fabric 1.20.1. O minimapa aparece
   automaticamente no canto superior direito.

## 3. Alternando Superfície/Subterrâneo no toque (Pojav)

Como o clique de mouse em telas de toque pode ser inconsistente, o jeito
mais confiável no PojavLauncher é:

1. Vá em **Configurações → Controles → Botões personalizados** do Pojav.
2. Adicione um novo botão e vincule ele à tecla **M**.
3. Toque nesse botão em jogo para alternar entre Superfície e Subterrâneo.

O botão desenhado ao lado do minimapa também funciona com mouse/touchpad
(quando o Pojav está em modo "mouse virtual").

## Estrutura do projeto

```
minimapa-mod/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── .github/workflows/build.yml   -> compila o .jar automaticamente
└── src/main/
    ├── java/com/gabedeveloper/minimapa/
    │   ├── MinimapaClient.java       -> inicialização e tecla de atalho
    │   ├── HudMinimapRenderer.java   -> desenho do mapa/entidades/botão
    │   └── mixin/MouseMixin.java     -> detecta clique no botão
    └── resources/
        ├── fabric.mod.json
        └── minimapa.mixins.json
```
